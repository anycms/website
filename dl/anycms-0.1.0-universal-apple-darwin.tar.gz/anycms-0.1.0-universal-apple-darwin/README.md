# AnyCMS SSG — macOS placeholder (v0.1.0)

A native macOS build of AnyCMS SSG is **not yet released**. This package
contains a placeholder `anycms` stub that explains how to install the real CLI.

## Get a working CLI on macOS

Build from source with Cargo:

```sh
cargo install --git https://github.com/anycms/anycms-ssg anycms-ssg-cli
```

Install Rust first if you don't have it: <https://rustup.rs>

Then run `anycms --help` to get started.
